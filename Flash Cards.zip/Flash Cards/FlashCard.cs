﻿using System;
using System.Collections.Generic;

namespace Flash_Cards
{
    public struct FlashCard
    {
        public string Vocab;
        

        public List<string> Definitions;

        public void Add(string deffo)
        {
            Definitions.Add(deffo);
        }
        public void Remove(int indexu)
        {
            Definitions.RemoveAt(indexu);
        }
        public void Save(string Sub)
        {
            SaveLoad.SaveCard(this, Sub);
        }
    }
}
