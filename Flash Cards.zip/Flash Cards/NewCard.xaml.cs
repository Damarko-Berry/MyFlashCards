﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Flash_Cards
{
    /// <summary>
    /// Interaction logic for NewCard.xaml
    /// </summary>
    public partial class NewCard : Window
    {
        public NewCard()
        {
            InitializeComponent();
        }
        FlashCard card = new FlashCard() { Definitions = new List<string>()};
        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            card.Vocab = Word.Text; 
            MainWindow.Main.UpdateButtons();
        }

        private void AddAns_Click(object sender, RoutedEventArgs e)
        {
            if (card.Definitions.Contains(NewAnwser.Text))
            {
                MessageBox.Show("This definition already exists");
                return;
            }
            card.Definitions.Add(NewAnwser.Text);
            Deffs.Text = String.Empty;
            for (int i = 0; i < card.Definitions.Count; i++)
            {
                Deffs.Text += card.Definitions[i]+"\n";
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveLoad.SaveCard(card, MainWindow.Main.SubjectDir);
            MainWindow.Main.UpdateButtons();
            this.Close();
        }
    }
}
