﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

using System.IO;

namespace Flash_Cards
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow Main;
        FlashCard Card = new FlashCard();
        public int Cdir =0;
        
        public string SubjectDir = String.Empty;
        DirectoryInfo directoryInfo => new DirectoryInfo(SubjectDir);
        Random Random = new Random();
        
        public MainWindow()
        {
            InitializeComponent();
            Options.Text = "Options";
            checkBox.IsChecked = isStartUp;
            if (!Directory.Exists(SaveLoad.ROOT))
            {
                Directory.CreateDirectory(SaveLoad.ROOT);
            }

            Main = this;



            UpdateButtons();
        }
        public void UpdateButtons()
        {
            NextQuestion.IsEnabled = false;
            if (Directory.GetDirectories(SaveLoad.ROOT).Length>0)
            {
                GetDir();
                NextQuestion.IsEnabled = Directory.GetFiles(SubjectDir).Length > 0;
            }
           
            RevealAnswer.IsEnabled = NextQuestion.IsEnabled;
            NewCards.IsEnabled = Directory.GetDirectories(SaveLoad.ROOT).Length>0;
            Previous.IsEnabled = Directory.GetDirectories(SaveLoad.ROOT).Length>1;
            Next.IsEnabled = Directory.GetDirectories(SaveLoad.ROOT).Length>1;
        }
        private void checkBox_Click(object sender, RoutedEventArgs e)
        {
            if (checkBox.IsChecked == true)
            {
                //File.Copy(Path.Combine(Directory.GetCurrentDirectory(), "Flash Cards"), Environment.GetFolderPath(Environment.SpecialFolder.Startup));
                MessageBox.Show("This program will start at startup\nin n future update");
                
            }
            else
            {
                MessageBox.Show("This program will no longer start at startup");
                
            }
        }
        
        bool isStartUp
        {
            get
            {
                return File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "Flash Cards.exe"));
            }
        }

        private void NextQuestion_Click(object sender, RoutedEventArgs e)
        {
            Card = SaveLoad.LoadCard(Random.Next(Directory.GetFiles(SubjectDir).Length), SubjectDir);
            Word.Text = Card.Vocab;
            Answer.Text = String.Empty;
        }
        void Reveal()
        {
            Answer.Text = "";
            for (int i = 0; i < Card.Definitions.Count; i++)
            {
                Answer.Text += Card.Definitions[i]+"\n";

            }
            
        }
        

        private void RevealAnswer_Click(object sender, RoutedEventArgs e)
        {
            Reveal();
            
        }

        private void NewCards_Click(object sender, RoutedEventArgs e)
        {
            NewCard  newCard = new NewCard();
            newCard.Show();
        }

        private void NewSubject_Click(object sender, RoutedEventArgs e)
        {
            SubjectMaker subjectMaker = new SubjectMaker();
            subjectMaker.Show();
        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            Cdir--;
            if (Cdir < 0)
            {
                Cdir = Directory.GetDirectories(SaveLoad.ROOT).Length - 1;
            }
            GetDir();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            Cdir++;
            if (Cdir >= Directory.GetDirectories(SaveLoad.ROOT).Length)
            {
                Cdir = 0;
            }
            GetDir();
        }

        void GetDir()
        {
            SubjectDir = Directory.GetDirectories(SaveLoad.ROOT)[Cdir];
            var i = new DirectoryInfo(SubjectDir);
            Topic.Content = i.Name;
        }
    }
}
