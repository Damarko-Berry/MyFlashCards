﻿using System;

using System.IO;

using System.Windows;
using System.Windows.Controls;



namespace Flash_Cards
{
    /// <summary>
    /// Interaction logic for SubjectMaker.xaml
    /// </summary>
    public partial class SubjectMaker : Window
    {
        public SubjectMaker()
        {
            InitializeComponent();
        }

        string NuSub;

        private void SubjectName_TextChanged(object sender, TextChangedEventArgs e)
        {
            NuSub= SubjectName.Text;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if(NuSub == String.Empty)
            {
                return;
            }
            Directory.CreateDirectory(Path.Combine(SaveLoad.ROOT, NuSub));
            MainWindow.Main.SubjectDir = Path.Combine(SaveLoad.ROOT, NuSub);
            DirectoryInfo directoryInfo = new DirectoryInfo(SaveLoad.ROOT);
            for (int i = 0; i < directoryInfo.GetDirectories().Length; i++)
            {
                if(directoryInfo.GetDirectories()[i].Name == NuSub)
                {
                    MainWindow.Main.Cdir = i;
                    break;
                }
            }
            MainWindow.Main.UpdateButtons();
            NewCard newCard = new NewCard();
            newCard.Show();
            Close();
        }
    }
}
