﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
namespace Flash_Cards
{
    public enum FileType { Card, Subject}
    static class SaveLoad
    {
        public readonly static string ROOT = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Flash Cards");
       
        

        public static void SaveCard(FlashCard ob, string subject)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(FlashCard));

            var writer = new StreamWriter(Path.Combine(subject, ob.Vocab + ".fc"));
            serializer.Serialize(writer, ob);


        }

        public static FlashCard LoadCard(int index, string subject)
        {
            TextReader writer = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(FlashCard));
                string u = Directory.GetFiles(subject)[index];
                writer = new StreamReader(u, false);
                return (FlashCard)serializer.Deserialize(writer);
            }
            catch
            {
                return new FlashCard();
            }
        }
    }
}
